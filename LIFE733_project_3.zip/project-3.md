## Project 3: A BioPython orthologue pipeline

In this project, you will build a small pipeline that retrieves a protein from the human proteome, searches it against a database of 10 mammal proteomes with BLAST to find likely orthologues, builds a protein multiple sequence alignment with MUSCLE, and creates phylogenetic trees. Your code will also produce plots of the results.

This project draws on Week 8 (running BLAST and reading FASTA with Biopython) and Week 9 (MUSCLE, `AlignIO`, conservation, and trees). Make sure the Week 8 and Week 9 examples work on your computer before you start. Answers to common questions are on the [Portfolio Project 3 FAQs](https://canvas.liverpool.ac.uk/courses/95131/pages/portopolio-project-3-faqs) page on Canvas.

:::{important} How you use generative AI is part of the mark
Part of the mark for this project comes from your `gai_log.txt`: a clear record of every prompt you gave a GAI tool, and what you did with the response. We want to see evidence that you used GAI **responsibly**, for example to debug your code, explain a concept, or review and refine code you wrote yourself.

Submissions produced by giving this brief to an AI coding agent or chatbot and submitting the generated pipeline will **score very poorly**. Read [GAI use in Project 3](#project-3-gai) before you start.
:::

(project-3-submit)=
### What you must submit for Project 3

Set up a new folder inside your `LIFE733` folder and keep all Project 3 work there:

```text
portfolio/
└── project-3/
    ├── project3_<student-id>.py       ← Your complete pipeline (one file)
    ├── project3_testing_report.pdf    ← Testing report (.pdf or .docx)
    ├── gai_log.txt                    ← Every GAI prompt you used (required)
    ├── A3_starter.py                  ← From Canvas
    ├── select_protein.py              ← From Canvas
    ├── UP000005640_9606.fasta         ← From Canvas (human proteome)
    └── 10_uniprot_mammals.fasta       ← From Canvas (10 mammal proteomes)
```

The two large FASTA files and the `UP_mammals` BLAST database files are only needed to run your pipeline. **Delete them before you create your portfolio ZIP**, so the ZIP stays small.

Your project must contain:

1. **One `.py` file** containing your complete pipeline, called `project3_<student-id>.py`.
2. **A testing report** (`.pdf` or `.docx`) showing your testing procedures. Include the output images and plots for **three input proteins**:
   1. `PM34_HUMAN`
   2. the protein assigned to you by `select_protein.py` (see below)
   3. one human protein you choose at random. There are about 20,000 to pick from, so two students should not choose the same one.
3. **`gai_log.txt`**, recording your GAI use as described in [GAI use in Project 3](#project-3-gai).

### Setup

Download these files from Canvas into your `project-3` folder:

- [`10_uniprot_mammals.fasta`](https://canvas.liverpool.ac.uk/courses/95131/files/14451743?module_item_id=2725161): 10 mammalian proteomes, previously downloaded from UniProt
- [`UP000005640_9606.fasta`](https://canvas.liverpool.ac.uk/courses/95131/files/14451769?module_item_id=2725162): the human proteome from UniProt (these proteins are also in the larger file)
- [`A3_starter.py`](https://canvas.liverpool.ac.uk/courses/95131/files/14451748?module_item_id=2725159): the starter code shown below
- [`select_protein.py`](https://canvas.liverpool.ac.uk/courses/95131/files/14451731?module_item_id=2725160): assigns your personal test protein.

If you have questions about the project, check the [Portfolio Project 3 FAQs](https://canvas.liverpool.ac.uk/courses/95131/pages/portopolio-project-3-faqs) on Canvas first.

Use the copy of `UP000005640_9606.fasta` from Canvas, not the Week 8 copy. `select_protein.py` selects a protein by its position in the file, so a different release of the proteome would give you a different protein.

Find your assigned protein by running this command in the terminal from your `project-3` folder (the script looks for `UP000005640_9606.fasta` in the current folder), using your nine-digit student ID without the brackets:

```bash
python select_protein.py [YOUR_STUDENT_ID]
```

Before you start, format the BLAST database. Run this command **once, from the command line, not from Python**:

```bash
makeblastdb -in 10_uniprot_mammals.fasta -dbtype prot -out UP_mammals
```

You now have a database ready for searching with `blastp`.

### Start from the starter code

All students must start their code with the following block, from [`A3_starter.py`](https://canvas.liverpool.ac.uk/courses/95131/files/14451748?module_item_id=2725159) on Canvas. You may add import statements above it.

```python
from Bio import SeqIO
import random
import os
from Bio import AlignIO
from Bio.Phylo.TreeConstruction import *
from Bio import Phylo
import matplotlib.pyplot as plt
import matplotlib

#Function to return command line arguments and print help message
def get_arguments_a3():
   import argparse
   parser = argparse.ArgumentParser(description="Assignment 3")
   parser.add_argument("-protname", type=str, help="Protein name",required=True)
   parser.add_argument("-blastcom", type=str, help="Blast executable",required=True)
   parser.add_argument("-musclecom", type=str, help="muscle executable",required=True)
   parser.add_argument("-fastafile", type=str, help="Source fasta file", required=True)
   parser.add_argument("-databasefasta", type=str, help="Target database file", required=True)
   args = parser.parse_args()
   return [arg for arg in vars(args).values()]


if __name__ == "__main__":
   input_args = get_arguments_a3()
   protein_name = input_args[0]
   blast_exe = input_args[1]
   muscle_exe = input_args[2]
   human_fasta = input_args[3]
   database_fasta = input_args[4]

print("Pipeline running with protein name",protein_name)
print("Running with BLAST as",blast_exe)
print("Running with muscle as",muscle_exe)
print("Source fasta:",human_fasta)
print("Database to search against:",database_fasta)

### Put your code to execute below
```

This block reads command-line arguments, in the same way that `blastp` and `muscle` read theirs. To supply them in VS Code, add them to the end of the run command in the terminal. Save your run commands in a text file and copy and paste them into the terminal. This saves typing and keeps a record of how you ran each test.

Here is an example run. Check the spacing carefully: put a space between arguments, and no space after each `-`.

```bash
python project3_<student-id>.py -protname PM34_HUMAN -blastcom blastp -musclecom muscle.exe -fastafile UP000005640_9606.fasta -databasefasta 10_uniprot_mammals.fasta
```

| Argument | What to supply |
| --- | --- |
| `-protname` | A human protein name from the FASTA file, such as `PM34_HUMAN` |
| `-blastcom` | How you run BLAST. If you type `blastp`, leave it as `blastp`. Otherwise give the name and location you use. |
| `-musclecom` | On a campus PC, use `muscle.exe`. Otherwise give the exact name and location of your MUSCLE executable (ask a demonstrator if in doubt). This lets us run your code with our own MUSCLE when marking. |
| `-fastafile` | The name and location of the source (human) FASTA file |
| `-databasefasta` | The name and location of the database FASTA file to search against |

The protein name is the third part of the identifier in each FASTA header. For example, in this header the protein name is `PM34_HUMAN`:

```text
>sp|O43808|PM34_HUMAN Peroxisomal membrane protein PMP34 OS=Homo sapiens OX=9606 GN=SLC25A17 PE=1 SV=1
```

Write the rest of your code at the bottom of the script. The variable `protein_name` is the main input for the first part.

### Part 1: BLAST

Use Biopython to read `UP000005640_9606.fasta` and find the protein of interest. You will need to **split** the record identifier to find a match.

Define three variables:

- `RND`: a random number between 1 and 10,000
- `blast_input`: a string of the form `temp_{RND}_blast_input.txt`, where `RND` is the value above
- `blast_output`: as above, but in the form `temp_{RND}_blast_output.tsv`.

Use `SeqIO` to write the human record you found to a new temporary file named `blast_input` ([Biopython SeqIO](https://biopython.org/wiki/SeqIO)).

Next, in your Python code, run a BLAST search of the protein against the 10-mammal database. BLAST must write its results to a tab-separated output file. **Use this exact code:**

```python
command = blast_exe + " -db UP_mammals -query "+ blast_input +" -out " + blast_output + " -outfmt 6"
```

Read the `blast_output` file, splitting each line on tabs. Column 1 is the input sequence, column 2 the hit sequence, column 11 the E-value, and column 12 the BLAST score. If you are comfortable with pandas (Week 11), you can use that instead.

Create a new FASTA file containing the record for each hit with an E-value below `1E-5`. Include only **one result per target species**: the best hit, which is the one with the highest BLAST score (see the hints below).

Once everything is working, use the `os` module to delete the BLAST input and output files to tidy your folder. Close your file handles first (`f.close()`).

#### Hints for writing the FASTA file of hits

- Use `SeqIO` to read the 10-mammal FASTA file, putting the records (`SeqRecord` objects) into a dictionary called `id_to_record` (key = ID, value = `SeqRecord`).
- You can work out the species from the final part of the identifier, for example `tr|A0A287B1G7|A0A287B1G7_PIG`. You can decide how best to do this. One option is a dictionary with the species name as the key. Another is a set, which works a bit like a dictionary without a value slot. BLAST results are already sorted from highest to lowest score.
- Create an empty list called `records_hit`. For each hit you want to keep, take its sequence record from `id_to_record` and append it to `records_hit`.
- After processing all the BLAST results, use `SeqIO` to write the best hit per species to a new FASTA file called `temp_{RND}_msa_input.fasta` (see Part 2).

### Part 2: Multiple sequence alignment

As in Part 1, define two variables, using the same random value:

- `msa_input`: `temp_{RND}_msa_input.fasta`
- `msa_output`: `temp_{RND}_msa_output.fasta`.

Run MUSCLE using exactly this command:

```python
muscle_exe + " -align " + msa_input + " -output "+ msa_output
```

Using techniques from Weeks 9 and 10, read the alignment with `AlignIO`. Plot the conservation of the most common amino acid along the alignment, and save the plot from your code to `{RND}_consensus_plot.png`. Your plot will look different from the example below, because it depends on the input protein. We want to see evidence that you tested a few different **random** examples, as described in [What you must submit for Project 3](#project-3-submit).

![Example consensus plot showing conservation of the most common amino acid along the alignment](images/project-3/consensus_plot_example.png)

### Part 3: Phylogenetics

Following the Week 9 guidance, create NJ and UPGMA trees from the alignment you made in Part 2, using the `blosum62` distance calculator. Save the trees to `temp_{RND}_phylo_NJ.png` and `temp_{RND}_phylo_UPGMA.png`.

Label the leaf nodes with the protein names, as in the example below. Colour the clades by `branch_length`:

| `branch_length` | Colour |
| --- | --- |
| below 0.01 | brown |
| below 0.02 | orange |
| below 0.03 | maroon |
| all other values | red |

![Example phylogenetic tree with protein-name labels and branches coloured by length](images/project-3/tree_example.png)

### Part 4: Advanced options

When you have completed all the other parts, you can add features that make your pipeline more powerful and user-friendly. You do not need to do all of these for full marks, but we will be looking for some creativity. For example, you could:

1. add other plots, such as a histogram of BLAST scores
2. add more features to the conservation plot, such as the amino acid at each position
3. let the user give several comma-separated protein names as input, and run the pipeline for each one, producing a separate set of outputs. If you add this, test that the pipeline still works with a single name, so that we can mark it.
4. use Matplotlib's [multipage PDF feature](https://matplotlib.org/stable/gallery/misc/multipage_pdf.html) to create one PDF that combines the plots from the different stages.

(project-3-gai)=
### GAI use in Project 3

The rules on the [Using Generative AI](gai.md) page apply to this project. Use Microsoft Copilot through your University account. In this project, **how you use GAI is assessed** (see the marking scheme below).

**What we want to see.** Responsible use of GAI as a tutor, reviewer, or debugging partner, after you have made your own attempt. For example:

- **debugging:** “Here is my loop that reads the BLAST output and the error it gives. Explain what is wrong; do not rewrite the code.”
- **explanation:** “What do the 12 columns of BLAST `-outfmt 6` output mean?” or “How does a Python set differ from a dictionary?”
- **refinement:** “Here is a function I wrote that keeps the best hit per species. Is it clear? Suggest improvements and explain why, but do not rewrite the whole thing.”
- **testing:** “Suggest small test cases for my function that extracts the species from a UniProt identifier.”

**What will score very poorly.** Pasting this brief, or large parts of it, into a chatbot or an AI coding agent (for example Copilot agent mode, ChatGPT, Claude, or Codex) and submitting the pipeline it produces. Such submissions will score very poorly on this project. The same applies if your code does not match the development shown in your log. You may be asked to explain any part of your code.

**How to record it.** Add an entry to `gai_log.txt` for **every** meaningful GAI interaction, using the template on the [Using Generative AI](gai.md) page. Each entry must include:

- the date and the tool used
- the part of the project (BLAST, MSA, phylogenetics, or advanced options)
- your own attempt before asking
- **the exact prompt you gave**, copied in full
- a brief summary of the response (not a full transcript)
- what you used, changed, or rejected, and why
- how you checked the result.

Record interactions that did not help, too. An honest log of a few well-chosen prompts is worth more than a long log of copied answers. Do not edit or remove entries to make your use look smaller.

If you did not use GAI at all, write `No GAI used for this project.` at the top of `gai_log.txt`. Then add a short development log: three or four dated entries describing a problem you hit, how you investigated it, and how you fixed and tested it. This is marked in the same way.

### Indicative Marking scheme for this section

| Component | Marks |
| --- | --- |
| BLAST: correct output produced | 20 |
| BLAST: code quality, documentation, and testing | 10 |
| MSA: correct outputs produced | 20 |
| MSA: code quality, documentation, and testing | 10 |
| Phylogenetics: correct outputs and testing | 10 |
| Phylogenetics: code quality, documentation, and testing | 5 |
| Advanced options (Part 4) | 10 |
| GAI log: prompts recorded clearly and completely, with evidence of your own attempts, learning-focused use, and checking of responses | 15 |
| **Total** | **100** |
