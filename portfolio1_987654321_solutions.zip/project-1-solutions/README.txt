LIFE733 Portfolio Project 1 — complete worked example
Student ID: 987654321

This archive is a fully completed reference example for all four parts. Each script includes comments explaining the operations. The generated data files are the inputs for this student ID.

To use it:
1. Extract this ZIP into a new folder.
2. Open the extracted project-1-solutions folder in VS Code (File > Open Folder).
3. Open Terminal > New Terminal.
4. Open one part folder at a time. The script and its data file are together.
5. Run `python part_a.py`, `python part_b.py`, `python part_c.py`, or `python part_d.py` from that part folder.
6. Compare your own portfolio work with the annotated script and correct_output.txt.

The correct_output.txt files are captured from these scripts and are included so every result can be checked exactly. This archive is a worked example: students should not submit it as their own work.
